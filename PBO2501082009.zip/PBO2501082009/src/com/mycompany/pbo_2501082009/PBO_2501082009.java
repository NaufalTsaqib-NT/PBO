/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pbo_2501082009;

/**
 *
 * @author LAB-SI-PC
 */
public class PBO_2501082009 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
    
}
